#!/usr/bin/env python3
"""Generate the Velvet Chords MPC screen skin.

Output: <out>/Velvet Chords - VST - Velvet Chords/
  TUI.json                 pages, component definitions, parameter bindings
  Q-Links.json             Q-Link assignments per page
  Q-Links - 8by1.json      same, for 8-Q-Link hardware (identical, as in the JV-880 reference)
  *.png                    every image the pages use

The file format mirrors a working community skin (JV-880 by sd88me) supplied as reference; it is not documented by
Akai. Parameters are bound by NAME: indices come from the built plugin via tools/list_params, so the skin can't drift
from the code.

Visual language: graphite hardware panel, ivory chord keys, one warm-gold accent for "selected / playing".
Every image is drawn at 3x and downsampled, so edges and gradients are smooth on the MPC screen.

usage: make_skin.py <plugin.so> <list_params binary> <out dir>
"""
import json, os, random, subprocess, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 1280, 628
SS = 3  # supersampling factor
FONT_DIR = "/usr/share/fonts/truetype/google-fonts"
LIVE_FONT = "Titillium Web"  # font the MPC uses for live text in the reference skin

# ---- palette (graphite + gold)
BG = "#111115"
HEADER_TOP, HEADER_BOT = "#1d1d23", "#16161b"
PANEL_TOP, PANEL_BOT = "#1c1c22", "#18181d"
PANEL_EDGE = "#2a2a33"
FIELD = "#0b0b0e"; FIELD_EDGE = "#2c2c35"
SEG_TOP, SEG_BOT = "#26262e", "#1e1e25"; SEG_EDGE = "#34343e"
GOLD = "#e8b04b"; GOLD_TOP, GOLD_BOT = "#f4c86e", "#d9982f"; GOLD_EDGE = "#b97e22"
ON_GOLD_INK = "#1b1611"
IVORY_TOP, IVORY_BOT = "#f6f2ea", "#e2dccd"; IVORY_EDGE = "#c4bcab"
INK = "#1e1b22"; FUNC_INK = "#6d6458"
BLACK_TOP, BLACK_BOT = "#3a3a44", "#141418"
TEXT = "#ece9e2"; MUTED = "#8a8795"; CAPTION = "#76737f"; TITLE = "#c9c5d0"
# legacy names used by the TUI helpers
ROSE = GOLD
BRIGHT = TEXT


def argb(hexrgb, a="ff"):
    return a + hexrgb.lstrip("#")


def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def font(weight, size):
    return ImageFont.truetype(os.path.join(FONT_DIR, "Poppins-%s.ttf" % weight), int(size))


# ---------------------------------------------------------------- parameters
def load_params(so, lister):
    out = subprocess.run([lister, so], capture_output=True, text=True, check=True).stdout
    p = {}
    for line in out.splitlines():
        i, name = line.split("\t")[:2]
        p[name] = int(i)
    return p


# ---------------------------------------------------------------- drawing primitives (all coordinates in final pixels)
def vgrad(w, h, top, bot):
    """vertical gradient image"""
    g = Image.new("RGBA", (1, 256))
    a, b = rgb(top), rgb(bot)
    for y in range(256):
        t = y / 255.0
        g.putpixel((0, y), tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3)) + (255,))
    return g.resize((max(1, w), max(1, h)), Image.BILINEAR)


def rounded_mask(w, h, r, corners=(True, True, True, True)):
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w - 1, h - 1), r, fill=255, corners=corners)
    return m


def shape(canvas, box, r, top, bot, edge=None, corners=(True, True, True, True), highlight=None, edge_w=1):
    """gradient-filled rounded rectangle with optional 1px edge and top highlight; box in canvas pixels"""
    x0, y0, x1, y1 = [int(v) for v in box]
    w, h = x1 - x0, y1 - y0
    fill = vgrad(w, h, top, bot)
    mask = rounded_mask(w, h, r, corners)
    canvas.paste(fill, (x0, y0), mask)
    d = ImageDraw.Draw(canvas)
    if highlight:  # thin top sheen, kept clear of the rounded corners
        inset = r if (corners[0] or corners[1]) else 0
        d.line((x0 + max(inset, edge_w), y0 + edge_w, x1 - 1 - max(inset, edge_w), y0 + edge_w), fill=highlight, width=edge_w)
    if edge:
        d.rounded_rectangle((x0, y0, x1 - 1, y1 - 1), r, outline=edge, width=edge_w, corners=corners)


def drop_shadow(canvas, box, r, offset=3, blur=4, alpha=140):
    x0, y0, x1, y1 = [int(v) for v in box]
    sh = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle((x0, y0 + offset, x1 - 1, y1 - 1 + offset), r, fill=(0, 0, 0, alpha))
    sh = sh.filter(ImageFilter.GaussianBlur(blur))
    canvas.alpha_composite(sh)


def text_at(d, xy, txt, f, fill, anchor="la"):
    d.text(xy, txt, font=f, fill=fill, anchor=anchor)


def text_center(d, box, txt, f, fill):
    x0, y0, x1, y1 = box
    _, t, _, b = d.textbbox((0, 0), "HX", font=f)  # cap-height centring, consistent across labels
    d.text(((x0 + x1) / 2, (y0 + y1 - (b - t)) / 2 - t), txt, font=f, fill=fill, anchor="ma")


class Art:
    """Draw at SS x, then downsample to (w, h)."""

    def __init__(self, w, h):
        self.w, self.h = w, h
        self.im = Image.new("RGBA", (w * SS, h * SS), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im)

    def b(self, *v):
        return [x * SS for x in v]

    def done(self):
        return self.im.resize((self.w, self.h), Image.LANCZOS)


# ---------------------------------------------------------------- images
class Images:
    def __init__(self, outdir):
        self.dir = outdir
        self.made = set()

    def save(self, name, img):
        if name not in self.made:
            img.save(os.path.join(self.dir, name), optimize=True)
            self.made.add(name)
        return name

    def pad_key(self, n, on):
        w, h = 148, 120
        a = Art(w, h)
        drop_shadow(a.im, a.b(3, 2, w - 3, h - 5), 10 * SS, offset=2 * SS, blur=3 * SS, alpha=150)
        if on:
            shape(a.im, a.b(3, 2, w - 3, h - 5), 10 * SS, GOLD_TOP, GOLD_BOT, edge=GOLD_EDGE, highlight="#fff3d0", edge_w=SS)
        else:
            shape(a.im, a.b(3, 2, w - 3, h - 5), 10 * SS, IVORY_TOP, IVORY_BOT, edge=IVORY_EDGE, highlight="#ffffff", edge_w=SS)
        text_at(a.d, a.b(14, 10), str(n), font("Medium", 12 * SS), GOLD_EDGE if on else "#a39b8b")
        return self.save("vc_padkey_%d_%s.png" % (n, "on" if on else "off"), a.done())

    def piano(self, pc, on, small=False):
        black = pc in (1, 3, 6, 8, 10)
        names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        if small:
            w, h = (40, 74) if black else (64, 120)
        else:
            w, h = (50, 92) if black else (80, 150)
        a = Art(w, h)
        r = 6 * SS
        corners = (False, False, True, True)
        if black:
            drop_shadow(a.im, a.b(2, 0, w - 2, h - 3), r, offset=2 * SS, blur=2 * SS, alpha=170)
            top, bot = (GOLD_TOP, GOLD_BOT) if on else (BLACK_TOP, BLACK_BOT)
            shape(a.im, a.b(2, 0, w - 2, h - 3), r, top, bot, edge="#0a0a0d" if not on else GOLD_EDGE, corners=corners, edge_w=SS)
            if not on:  # key-top bevel
                shape(a.im, a.b(6, 0, w - 6, h - 14), 4 * SS, "#44444f", "#24242b", corners=corners)
        else:
            top, bot = (GOLD_TOP, GOLD_BOT) if on else (IVORY_TOP, IVORY_BOT)
            shape(a.im, a.b(1, 0, w - 1, h), r, top, bot, edge=GOLD_EDGE if on else IVORY_EDGE, corners=corners, edge_w=SS)
            y0, y1 = (h - 54, h - 32) if not small else (h - 36, h - 14)
            text_center(a.d, a.b(0, y0, w, y1), names[pc], font("Medium", (15 if not small else 13) * SS),
                        ON_GOLD_INK if on else "#7d7568")
        return self.save("vc_%skey_%d_%s.png" % ("e" if small else "", pc, "on" if on else "off"), a.done())

    def dot(self, on):
        a = Art(18, 18)
        if on:
            a.d.ellipse(a.b(2, 2, 16, 16), fill="#1b1611")
            a.d.ellipse(a.b(4, 4, 14, 14), fill=GOLD)
        return self.save("vc_dot_%s.png" % ("on" if on else "off"), a.done())

    def seg(self, group, i, n, text, w, h, on):
        """joined segmented control: outer corners rounded only on the ends"""
        a = Art(w, h)
        first, last = i == 0, i == n - 1
        corners = (first, last, last, first)
        if on:
            shape(a.im, a.b(0, 0, w, h), 8 * SS, GOLD_TOP, GOLD_BOT, edge=GOLD_EDGE, corners=corners, highlight="#fff3d0", edge_w=SS)
        else:
            shape(a.im, a.b(0, 0, w, h), 8 * SS, SEG_TOP, SEG_BOT, edge=SEG_EDGE, corners=corners, highlight="#3c3c47", edge_w=SS)
        text_center(a.d, a.b(0, 0, w, h), text, font("Medium" if on else "Regular", (15 if w > 50 else 13) * SS),
                    ON_GOLD_INK if on else "#b3b0bd")
        return self.save("vc_seg_%s_%d_%s.png" % (group, i, "on" if on else "off"), a.done())

    def pill(self, on):
        w, h = 64, 32
        a = Art(w, h)
        if on:
            shape(a.im, a.b(0, 0, w, h), 16 * SS, GOLD_TOP, GOLD_BOT, edge=GOLD_EDGE, edge_w=SS)
        else:
            shape(a.im, a.b(0, 0, w, h), 16 * SS, "#18181d", "#24242b", edge=SEG_EDGE, edge_w=SS)
        cx = (w - 16) if on else 16
        drop_shadow(a.im, a.b(cx - 12, 4, cx + 12, h - 4), 12 * SS, offset=SS, blur=SS * 2, alpha=150)
        shape(a.im, a.b(cx - 12, 4, cx + 12, h - 4), 12 * SS, "#ffffff" if on else "#a7a4b0", "#e9e4da" if on else "#7c7987")
        return self.save("vc_pill_%s.png" % ("on" if on else "off"), a.done())

    def arrow(self, nxt):
        a = Art(44, 44)
        shape(a.im, a.b(0, 0, 44, 44), 8 * SS, SEG_TOP, SEG_BOT, edge=SEG_EDGE, highlight="#3c3c47", edge_w=SS)
        pts = [(19, 15), (26, 22), (19, 29)] if nxt else [(25, 15), (18, 22), (25, 29)]
        a.d.line([(x * SS, y * SS) for x, y in pts], fill=TEXT, width=int(2.5 * SS), joint="curve")
        return self.save("vc_arrow_%s.png" % ("next" if nxt else "prev"), a.done())

    def button(self, name, text, w, h, on):
        a = Art(w, h)
        if on:
            shape(a.im, a.b(0, 0, w, h), 9 * SS, GOLD_TOP, GOLD_BOT, edge=GOLD_EDGE, highlight="#fff3d0", edge_w=SS)
        else:
            shape(a.im, a.b(0, 0, w, h), 9 * SS, SEG_TOP, SEG_BOT, edge=GOLD_EDGE, highlight="#3c3c47", edge_w=SS)
        text_center(a.d, a.b(0, 0, w, h), text, font("Medium", 16 * SS), ON_GOLD_INK if on else GOLD)
        return self.save("vc_btn_%s_%s.png" % (name, "on" if on else "off"), a.done())


class Background:
    """Full-page art: header bar, panels, LCD fields and captions are baked in; live text sits on top."""

    def __init__(self, page_title):
        self.a = Art(W, H)
        im = self.a.im
        im.paste(vgrad(W * SS, H * SS, "#141418", "#0e0e11"), (0, 0))
        # faint grain so large dark areas don't band on the MPC screen
        noise = Image.effect_noise((W * SS, H * SS), 24).convert("L")
        grain = Image.merge("RGBA", (noise, noise, noise, Image.new("L", noise.size, 9)))
        im.alpha_composite(grain)
        # header bar
        im.paste(vgrad(W * SS, 64 * SS, HEADER_TOP, HEADER_BOT), (0, 0))
        self.a.d.line(self.a.b(0, 64, W, 64), fill="#2b2b34", width=SS)
        self.a.d.line(self.a.b(0, 65, W, 65), fill="#0a0a0c", width=SS)
        # logo mark: a stack of three gold bars (a chord), then the wordmark
        for k, (wbar, op) in enumerate(((22, "ff"), (16, "cc"), (10, "99"))):
            y = 22 + k * 8
            self.a.d.rounded_rectangle(self.a.b(24, y, 24 + wbar, y + 5), 2.5 * SS, fill="#" + GOLD.lstrip("#") + op)
        text_at(self.a.d, self.a.b(56, 16), "Velvet Chords", font("Bold", 24 * SS), TEXT)
        self.a.d.line(self.a.b(236, 22, 236, 44), fill="#34343e", width=SS)
        text_at(self.a.d, self.a.b(250, 22), page_title, font("Regular", 15 * SS), MUTED)

    @property
    def d(self):
        return self.a.d

    def panel(self, box, title=None):
        x0, y0, x1, y1 = box
        drop_shadow(self.a.im, self.a.b(x0, y0, x1, y1), 12 * SS, offset=2 * SS, blur=4 * SS, alpha=120)
        shape(self.a.im, self.a.b(x0, y0, x1, y1), 12 * SS, PANEL_TOP, PANEL_BOT, edge=PANEL_EDGE, highlight="#2f2f39", edge_w=SS)
        if title:
            text_at(self.a.d, self.a.b(x0 + 16, y0 + 10), title, font("Medium", 14 * SS), TITLE)

    def field(self, x, y, w, h):
        """recessed LCD-style readout"""
        shape(self.a.im, self.a.b(x, y, x + w, y + h), 8 * SS, "#08080a", "#0f0f13", edge=FIELD_EDGE, edge_w=SS)
        self.a.d.line(self.a.b(x + 8, y + 1.5, x + w - 8, y + 1.5), fill="#000000", width=SS)  # inner top shadow
        self.a.d.line(self.a.b(x + 8, y + h + 0.5, x + w - 8, y + h + 0.5), fill="#24242c", width=SS)  # lower lip

    def caption(self, x, y, txt):
        text_at(self.a.d, self.a.b(x, y), txt, font("Medium", 12.5 * SS), CAPTION)

    @property
    def im(self):
        return self.a.done().convert("RGB")


# ---------------------------------------------------------------- TUI.json building blocks
def remap(pairs):
    return {"version": 1, "map": [{"key": k, "value": "Parameter %d" % v} for k, v in pairs]}


def bounds(x, y, w, h, focus="No", visible="Always", invalid="Show", inval=None):
    return {"version": 2, "acceptsHWFocus": focus, "showWhenDataModelInvalid": invalid, "whenVisible": visible,
            "boundsType": "Absolute", "bounds": "%d %d %d %d" % (x, y, w, h), "additionalInvalidatingHandles": inval or []}


def action(on, handler, overlay=""):
    return {"version": 2, "onAction": on, "handler": handler, "handleName": "" if handler == "Show Overlay" else "Data",
            "additionalData": overlay, "handle remapping": {"version": 1, "map": []}}


A_QLINK = action("Mouse Down", "Q-Link")
A_OVERLAY_DBL = action("Double Click", "Show Overlay", "knob overlay")
A_OVERLAY_ENTER = action("Enter Pressed", "Show Overlay", "knob overlay")
A_TOGGLE_ENTER = action("Enter Pressed", "Toggle Switch")
A_TOGGLE_DOWN = action("Mouse Down", "Toggle Switch")


def sub(name, ctype, data, b):
    return {"version": 2, "componentData": {"version": 1, "name": name, "type": ctype, "data": data},
            "handle remapping": {"version": 1, "map": []}, "bounds": b}


def focus_sub(w, h):
    return sub("Focus", "Focus", {"version": 1, "backgroundColour": "00000000", "outlineColour": argb(ROSE),
                                  "backgroundInset": 2.0, "outlineThickness": 2.0}, bounds(0, 0, w, h, visible="WhenFocussed"))


def label_sub(name, handle, x, y, w, h, size, colour, just="horizontallyCentred verticallyCentred"):
    return sub(name, "Label", {"version": 1, "textStyle": {"version": 1, "font": {"version": 1, "name": LIVE_FONT, "style": "SemiBold",
               "height": float(size)}, "colour": argb(colour), "justification": just, "case": "Original"},
               "type": "Value", "handleName": handle}, bounds(x, y, w, h))


def button_sub(on, off, bid, n, w, h, x=0, y=0):
    return sub("Button", "Button", {"version": 2, "onImage": on, "offImage": off, "buttonId": bid, "numButtonsInGroup": n,
                                    "handleName": "Data", "gestureBehaviour": "Instant"}, bounds(x, y, w, h))


def definition(actions, comps, bgcolour="0", ignore=False):
    return {"version": 4, "actions": actions,
            "backgroundData": {"version": 1, "focussed": {"version": 1, "colour": bgcolour, "image": ""},
                               "unfocussed": {"version": 1, "colour": bgcolour, "image": ""}},
            "ignoreMousePresses": ignore, "disableCoarseDataWheel": False, "repeats": 1, "hideQLinkBounds": True,
            "componentsData": comps}


class Skin:
    def __init__(self, params, outdir):
        self.P = params
        self.img = Images(outdir)
        self.defs = {}
        self.pages = []

    def p(self, name):
        if name not in self.P:
            raise KeyError("plugin has no parameter %r" % name)
        return self.P[name]

    def define(self, key, value):
        if key not in self.defs:
            self.defs[key] = value
        return key

    @staticmethod
    def place(deftype, name, x, y, w, h, pairs, focus="No", inval=None):
        return {"version": 2, "componentData": {"version": 1, "name": name, "type": deftype, "data": {"version": 1, "handleName": "Data"}},
                "handle remapping": remap(pairs), "bounds": bounds(x, y, w, h, focus=focus, invalid="Hide", inval=inval)}

    # ---- widgets
    def value_field(self, comps, bg, param, x, y, w, h, size=21, colour=TEXT, editable=True, caption=None):
        bg.field(x, y, w, h)
        if caption:
            bg.caption(x + 2, y - 20, caption)
        key = "vcField_%dx%d_%d_%s_%s" % (w, h, size, colour.lstrip("#"), "e" if editable else "r")
        comps_def = ([focus_sub(w, h)] if editable else []) + [label_sub("Value", "Data", 12, 0, w - 24, h, size, colour)]
        self.define(key, definition([A_QLINK, A_OVERLAY_DBL, A_OVERLAY_ENTER] if editable else [], comps_def, ignore=not editable))
        comps.append(self.place(key, caption or param, x, y, w, h, [("Data", self.p(param))], focus="Yes" if editable else "No"))

    def stepper(self, comps, bg, param, prev, nxt, x, y, w, caption):
        """prev arrow, value field, next arrow"""
        for is_next, px, trig in ((False, x, prev), (True, x + 44 + 6 + w + 6, nxt)):
            im = self.img.arrow(is_next)
            key = self.define("vcArrow_%s" % ("next" if is_next else "prev"),
                              definition([A_TOGGLE_ENTER], [button_sub(im, im, 1, 1, 44, 44)]))
            comps.append(self.place(key, "next" if is_next else "prev", px, y, 44, 44, [("Data", self.p(trig))]))
        self.value_field(comps, bg, param, x + 50, y, w, 44, size=21, caption=None)
        if caption:
            bg.caption(x + 2, y - 20, caption)

    def segments(self, comps, bg, group, param, labels, x, y, w, h, caption=None):
        """joined segmented control (no gaps), one image pair per option"""
        if caption:
            bg.caption(x + 2, y - 20, caption)
        n = len(labels)
        for i, t in enumerate(labels):
            on = self.img.seg(group, i, n, t, w, h, True)
            off = self.img.seg(group, i, n, t, w, h, False)
            key = self.define("vcSeg_%s_%d" % (group, i), definition([A_QLINK], [button_sub(on, off, i, n, w, h)]))
            comps.append(self.place(key, "%s %s" % (caption or group, t), x + i * w, y, w, h,
                                    [("Data", self.p(param))], focus="Yes" if i == 0 else "No"))

    def toggle(self, comps, bg, param, x, y, caption):
        on, off = self.img.pill(True), self.img.pill(False)
        key = self.define("vcToggle", definition([A_QLINK, A_TOGGLE_ENTER], [focus_sub(64, 32), button_sub(on, off, 1, 1, 64, 32)]))
        if caption:
            bg.caption(x + 2, y - 20, caption)
        comps.append(self.place(key, caption or param, x, y, 64, 32, [("Data", self.p(param))], focus="Yes"))

    def action_button(self, comps, bg, name, text, param, x, y, w=200, h=44):
        on, off = self.img.button(name, text, w, h, True), self.img.button(name, text, w, h, False)
        key = self.define("vcBtn_%s" % name, definition([A_TOGGLE_ENTER], [button_sub(on, off, 1, 1, w, h)]))
        comps.append(self.place(key, text, x, y, w, h, [("Data", self.p(param))]))

    def readout(self, comps, bg, param, x, y, w, h, size=18, colour=TEXT, caption=None):
        self.value_field(comps, bg, param, x, y, w, h, size=size, colour=colour, editable=False, caption=caption)

    def pad_grid(self, comps, x0, y0):
        """16 chord keys: chord name + function come from the plugin; the lit key is 'Screen pad'."""
        w, h, gap = 148, 120, 8
        for k in range(16):
            on, off = self.img.pad_key(k + 1, True), self.img.pad_key(k + 1, False)
            key = self.define("vcPadKey_%d" % (k + 1), definition([A_QLINK], [
                button_sub(on, off, k + 1, 17, w, h),
                label_sub("Chord", "Chord", 8, 26, w - 16, 44, 27, INK),
                label_sub("Function", "Function", 8, 70, w - 16, 28, 16, FUNC_INK),
            ]))
            x = x0 + (k % 8) * (w + gap)
            y = y0 + (k // 8) * (h + gap)
            comps.append(self.place(key, "Pad %d" % (k + 1), x, y, w, h,
                                    [("Data", self.p("Screen pad")), ("Chord", self.p("Pad %d chord" % (k + 1))),
                                     ("Function", self.p("Pad %d function" % (k + 1)))]))

    def keyboard(self, comps, param, x0, y0, small=False, dots=False):
        whites = [0, 2, 4, 5, 7, 9, 11]
        ww, wh = (64, 120) if small else (80, 150)
        bw, bh = (40, 74) if small else (50, 92)
        pos = {}
        for i, pc in enumerate(whites):
            pos[pc] = (x0 + i * ww, y0, ww, wh)
        for pc, left in ((1, 0), (3, 2), (6, 5), (8, 7), (10, 9)):
            pos[pc] = (pos[left][0] + ww - bw // 2, y0, bw, bh)
        order = whites + [1, 3, 6, 8, 10]  # black keys last, on top
        for pc in order:
            x, y, w, h = pos[pc]
            on, off = self.img.piano(pc, True, small), self.img.piano(pc, False, small)
            key = self.define("vc%sKey_%d" % ("E" if small else "", pc), definition([A_QLINK], [button_sub(on, off, pc, 12, w, h)]))
            comps.append(self.place(key, "Key %d" % pc, x, y, w, h, [("Data", self.p(param))]))
        if dots:
            don, doff = self.img.dot(True), self.img.dot(False)
            key = self.define("vcScaleDot", definition([], [button_sub(don, doff, 1, 1, 18, 18)], ignore=True))
            names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
            for pc in order:
                x, y, w, h = pos[pc]
                comps.append(self.place(key, "in scale %s" % names[pc], x + (w - 18) // 2, y + h - 24, 18, 18,
                                        [("Data", self.p("Scale has %s" % names[pc]))]))

    # ---- pages
    def page(self, tab_name, fn, comps, bg_name, bg):
        img = self.img.save(bg_name, bg.im)
        background = sub("Background", "Image", {"version": 2, "imageType": "Regular", "colour": "0", "image": img}, bounds(0, 0, W, H))
        key = "%s|%s" % (tab_name.upper(), tab_name)
        self.define(key, definition([], [background] + comps, bgcolour=argb(BG)))
        self.pages.append({"version": 3, "tabName": tab_name, "fnKeyIndex": fn, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
                           "componentName": key, "initialSize": "0 0 %d %d" % (W, H), "scale": 1.0})

    def build(self):
        modes = ["Song", "Scale", "R&B kit", "Types", "Custom"]
        voicings = ["Bass + upper", "Close", "Drop 2", "Spread", "Upper"]
        banks = ["A", "B", "C", "D"]
        notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

        # ---------- Play
        bg = Background("Play")
        c = []
        self.segments(c, bg, "mode", "Mode", modes, 470, 12, 104, 40)
        bg.d.text(bg.a.b(1020, 26), "Bank", font=font("Medium", 12.5 * SS), fill=CAPTION)
        self.segments(c, bg, "bank", "Screen bank", banks, 1064, 12, 50, 40)
        bg.panel((12, 76, 1268, 156))
        self.stepper(c, bg, "Song", "Song prev", "Song next", 28, 102, 430, "Song")
        self.stepper(c, bg, "Section", "Section prev", "Section next", 608, 102, 200, "Section")
        self.readout(c, bg, "Info", 924, 102, 328, 44, size=15, colour=MUTED, caption="Song data")
        bg.panel((12, 164, 1268, 428))
        self.pad_grid(c, 20, 172)
        bg.panel((12, 436, 600, 620))
        bg.caption(30, 444, "Key")
        self.keyboard(c, "Key", 30, 462, dots=True)
        bg.d.text(bg.a.b(598 - 14, 444), "dots show the scale", font=font("Regular", 12 * SS), fill="#5f5c68", anchor="ra")
        bg.panel((608, 436, 1268, 620))
        self.stepper(c, bg, "Scale", "Scale prev", "Scale next", 624, 462, 530, "Scale")
        self.segments(c, bg, "voicing", "Voicing", voicings, 624, 530, 126, 36, caption="Voicing")
        self.readout(c, bg, "Now playing", 624, 576, 628, 36, size=19, colour=GOLD)
        self.page("Play", 0, c, "vc_bg_play.png", bg)

        # ---------- Perform
        bg = Background("Perform")
        c = []
        L, R = 30, 664
        bg.panel((12, 76, 632, 620))
        self.segments(c, bg, "sound", "Sound", ["E. piano", "Pad", "Organ", "Silent"], L, 116, 142, 40, caption="Instrument")
        self.value_field(c, bg, "Tone", L, 212, 182, 44, caption="Tone")
        self.value_field(c, bg, "Release", L + 192, 212, 182, 44, caption="Release")
        self.value_field(c, bg, "Volume", L + 384, 212, 182, 44, caption="Volume")
        self.segments(c, bg, "vel", "Velocity", ["Linear", "Soft", "Hard", "Fixed"], L, 298, 142, 40, caption="Velocity")
        self.value_field(c, bg, "Strum", L, 382, 182, 44, caption="Strum")
        self.segments(c, bg, "strumdir", "Strum dir", ["Up", "Down", "Alternate"], L + 192, 384, 124, 40, caption="Direction")
        self.segments(c, bg, "arp", "Arp", ["Off", "Up", "Down", "Up-down", "Random"], L, 468, 113, 40, caption="Arpeggiator")
        self.segments(c, bg, "rate", "Arp rate", ["1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32"], L, 552, 94, 40, caption="Rate")
        bg.panel((648, 76, 1268, 620))
        self.segments(c, bg, "voicing2", "Voicing", voicings, R, 116, 118, 40, caption="Voicing")
        self.segments(c, bg, "inv", "Inversion", ["Root", "1st", "2nd", "3rd"], R, 212, 147, 40, caption="Inversion")
        self.segments(c, bg, "oct", "Octave", ["-2", "-1", "0", "+1", "+2"], R, 298, 118, 40, caption="Octave")
        self.value_field(c, bg, "Transpose", R, 382, 182, 44, caption="Transpose (song mode)")
        self.toggle(c, bg, "Voice lead", R + 214, 388, "Voice leading")
        self.toggle(c, bg, "MIDI out", R + 360, 388, "MIDI out")
        self.value_field(c, bg, "Pad 1 note", R, 468, 182, 44, caption="Pad 1 note")
        self.action_button(c, bg, "learn", "Learn pad 1", "Learn pad 1", R + 192, 468)
        self.action_button(c, bg, "export", "Export MIDI", "Export MIDI", R, 552, w=182)
        self.readout(c, bg, "Export MIDI", R + 192, 552, 396, 44, size=16, colour=MUTED)
        self.page("Perform", 1, c, "vc_bg_perform.png", bg)

        # ---------- Edit
        bg = Background("Edit pads")
        c = []
        bg.d.text(bg.a.b(452, 26), "Pad", font=font("Medium", 12.5 * SS), fill=CAPTION)
        self.stepper(c, bg, "Edit pad", "Edit pad prev", "Edit pad next", 484, 10, 96, None)
        bg.d.text(bg.a.b(800, 26), "Tap a key to edit it", font=font("Medium", 12.5 * SS), fill=CAPTION)
        self.toggle(c, bg, "Edit follows pad", 942, 16, None)
        self.segments(c, bg, "bank3", "Screen bank", banks, 1064, 12, 50, 40)
        bg.panel((12, 76, 1268, 340))
        self.pad_grid(c, 20, 84)
        bg.panel((12, 348, 484, 620))
        bg.caption(30, 358, "Root")
        self.keyboard(c, "Edit root", 30, 378, small=True)
        self.action_button(c, bg, "copy", "Copy layout to Custom", "Copy to Custom", 30, 560, w=436)
        bg.panel((492, 348, 1268, 620))
        self.segments(c, bg, "bass", "Edit bass", ["Root"] + notes, 508, 378, 57, 40, caption="Bass note")
        self.stepper(c, bg, "Edit type", "Edit type prev", "Edit type next", 508, 464, 420, "Chord type")
        self.readout(c, bg, "Now playing", 1040, 464, 212, 44, size=14, colour=GOLD, caption="Now playing")
        self.segments(c, bg, "einv", "Edit inversion", ["Root", "1st", "2nd", "3rd"], 508, 560, 88, 40, caption="Inversion")
        self.segments(c, bg, "eoct", "Edit octave", ["-2", "-1", "0", "+1", "+2"], 892, 560, 72, 40, caption="Octave")
        self.page("Edit", 2, c, "vc_bg_edit.png", bg)

    def tui(self):
        return {"pageData": {"version": 1, "componentDefinitions": {"version": 2, "importFiles": [
            "/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json",
            "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
            "localComponentDefinitions": [{"key": k, "value": v} for k, v in self.defs.items()]},
            "info": {"version": 1, "type": "CompleteDescription"}, "tabs": self.pages}}

    def qlinks(self):
        def m(names):
            names = (names + [None] * 16)[:16]
            return {"Q-Link %d" % (i + 1): (self.p(n) if n else -1) for i, n in enumerate(names)}
        play = ["Mode", "Song", "Section", "Screen bank", "Key", "Scale", "Transpose", "Voicing",
                "Inversion", "Octave", "Voice lead", "Sound", "Strum", "Arp", "Tone", "Volume"]
        perform = ["Sound", "Tone", "Release", "Volume", "Velocity", "Strum", "Strum dir", "Arp",
                   "Arp rate", "Voicing", "Inversion", "Octave", "Transpose", "Voice lead", "MIDI out", "Pad 1 note"]
        edit = ["Edit pad", "Edit root", "Edit type", "Edit bass", "Edit inversion", "Edit octave", "Edit follows pad",
                "Screen bank", "Mode", "Voicing", "Sound", "Volume"]
        tabs = [{"Tab": i + 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": m(x)} for i, x in enumerate([play, perform, edit])]
        return {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
                "Screen Mode Q-Links": {"version": 4, "map": tabs}, "Program Mode Q-Links": m(play)}


def main():
    so, lister, out = sys.argv[1], sys.argv[2], sys.argv[3]
    params = load_params(so, lister)
    skin_dir = os.path.join(out, "Velvet Chords - VST - Velvet Chords")
    os.makedirs(skin_dir, exist_ok=True)
    s = Skin(params, skin_dir)
    s.build()
    json.dump(s.tui(), open(os.path.join(skin_dir, "TUI.json"), "w"), indent=4)
    q = s.qlinks()
    for name in ("Q-Links.json", "Q-Links - 8by1.json"):
        json.dump(q, open(os.path.join(skin_dir, name), "w"), indent=4)
    print("skin: %s (%d definitions, %d pages, %d images)" % (skin_dir, len(s.defs), len(s.pages), len(s.img.made)))


if __name__ == "__main__":
    main()
