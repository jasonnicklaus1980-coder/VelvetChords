# Velvet Chords 1.0.0: verification report

## Integration method

MPC OS on first-generation devices runs a JUCE-based plugin host that loads VST2 shared libraries listed under
`pluginList-arm` in `MPC.settings`. This was learned from a working community plugin package (JV-880) supplied by the
user, not from Akai documentation. Velvet Chords uses the same route: a 32-bit ARM hard-float VST2 `.so` in `/sdcard/vst`.
It is an **instrument** plugin: MPC pads send notes to it, and it plays chords with its own sound engine. That avoids
depending on whether MPC routes MIDI *out* of plugins, which is unknown.

## What was tested, and where

| Area | How it was tested | Result |
|---|---|---|
| Chord types (40) | Each checked against an independent spelled-note table, plus aliases | Pass |
| Voicings | 192,000 combinations: every type x 12 roots x slash basses x 5 styles x 4 inversions x 5 octaves; pitch classes, bass note, order, range | Pass |
| Transposition | Every type in all 12 keys keeps its interval shape; transposed song pads keep quality | Pass |
| Voice leading | Top voice of a voice-led progression moves no more than a 4th | Pass |
| Smart Scale | Diatonic chords for C major and A harmonic minor checked by name; all 17 scales x 12 keys stay in scale | Pass |
| Song data | All chord symbols parse, whole bars only, no duplicate ids, none claims `verified` | Pass |
| Note handling | 4,000 random blocks of overlapping notes, sustain, strum, arp, layout changes; then all off | No held chords, no stuck voices, MIDI out on/off balanced |
| Retrigger, sustain | Double note-on with one note-off; pedal hold and release | Pass |
| Timing | Strum gaps exact to the sample (2,400 at 50 ms); arp steps exact (6,000 samples at 120 BPM 1/16) | Pass |
| Plugin binary interface | Test host loads the `.so` like a VST2 host: 33 parameters, displays, all 15 songs sound, rapid triggering, Learn, edits, project save/restore, bad-data rejection, Export | 433 checks pass |
| Exported files | 67 MIDI and 67 `.progression` files parsed by an independent validator; database notes equal MIDI notes | Pass |
| Pitch | Demo render analysed by FFT: Dbmaj7 sounds C#, F, G#, C within 0.03 semitone | Pass |
| Screen skin | Format copied from the working JV-880 skin (TUI.json pages, component definitions, Q-Links files). Every binding resolves to a real parameter, all 217 images exist, regenerating gives identical files, and all three pages render correctly in an offline preview driven by the plugin's live parameter text | Pass (offline) |
| Screen helpers | Through the plugin interface: on-screen chord labels follow mode, key and bank; scale dots follow key and scale; prev/next buttons step and reset; tapping a key auditions it and stops by itself; playing a pad moves the screen to its bank and lights it; helpers can't be automated | Pass |
| Installer | Install, upgrade, uninstall, damaged-file detection, settings with and without an existing plugin list, on a simulated MPC filesystem with stubbed system commands | Pass |

All of the above ran on x86_64 Linux. **Nothing has run on ARM or on an MPC yet.** `scripts/build-arm.sh` runs the
same test host on the ARM build under the qemu emulator; that is the next level of confidence, still not hardware.

## Must be tested on the MPC

1. The plugin appears in the plugin browser and loads without crashing MPC.
2. How parameters display without a custom screen skin, and which ones the Q-Links reach.
3. Which notes the pads send on a plugin track (Learn pad 1 handles any answer).
4. Latency and CPU use with long chords, strum and arp at your project's buffer size.
5. Project save and reload keeps custom pads.
6. Export MIDI writes to the internal drive's `Velvet Chords` folder and the files show up in the MPC browser.
7. Whether MPC passes the plugin's MIDI out to other tracks or external MIDI (default off).
8. Whether MPC accepts the `.progression` files (compare with one saved from your MPC).
9. The skin: that MPC finds it under `/sdcard/Synths` by its folder name, that live text uses the MPC's Titillium Web font at the sizes chosen, that segment buttons set the right values, that the screen repaints when you hit a pad (the plugin asks the host to refresh), and that double-tapping a value field opens MPC's knob overlay.

## Song library status

15 songs, 17 sections, 1961-2013. **Verified: 0.** All are `unverified-analysis`: recalled common charts and harmonic
analysis, with no licensed transcription consulted. Confidence: high 8, medium 6, low 1. Partial entries are noted in each
song's notes (for example, My Girl's later modulations and Superstition's chorus are not included). No lyrics or
notation are included.

The 500-song goal is not met and shouldn't be met by guessing. Each new song needs checking against the recording
before its status can be raised.

## Voicings

Every pad and MIDI voicing is a **generated performance voicing** (default: bass note plus a voice-led upper
structure). None is claimed to be the voicing on the original record. Chord symbols and notes are stored together in
`database.json` so the name and the sound can't disagree.

## Known limitations

- The skin format was learned from one community skin, not from Akai documentation. It uses only building blocks that skin uses (images, buttons, value labels, overlays), no knobs or popups.
- One pad = one chord; songs with more than 16 chord changes in a section are cut to 16 pads (MIDI export keeps the full section).
- Pad display names on the MPC pads themselves aren't possible from a plugin; the *Now playing* parameter shows the chord.
- Tempo and time signature for songs are placeholders (90 BPM, 4/4) because none is verified; host tempo is used for exports.
