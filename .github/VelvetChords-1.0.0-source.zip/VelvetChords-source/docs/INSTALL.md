# Velvet Chords 1.0.0

A chord-pad instrument plugin for MPC OS. Each pad plays a full chord through a built-in electric piano, pad or organ sound, with song sections, a Smart Scale mode, an R&B chord kit and 64 editable custom pads.

It is a native MPC OS plugin (VST2 `.so`) loaded by MPC's built-in plugin host, installed the same way as community plugins such as the JV-880 port.

## Requirements

- A first-generation MPC OS standalone device (32-bit ARM: MPC X, Live, Live II, One, Key 61, Force). The installer refuses anything else.
- **Root shell access (SSH).** Stock MPC OS doesn't offer this; you need a modded unit.
- Installing plugins this way is unofficial and not supported by Akai. Back up first and use at your own risk.

## Install (scripted)

1. Unzip, then copy the whole folder to the device:
   `scp -r VelvetChords-1.0.0 root@<device-ip>:/tmp/`
2. Run the installer:
   `ssh root@<device-ip> sh /tmp/VelvetChords-1.0.0/install.sh`

The installer checks the device and file checksums, **stops MPC** (save your project first), copies the plugin to `/sdcard/vst/velvetchords.so`, the screen skin to `/sdcard/Synths/Velvet Chords - VST - Velvet Chords/`, copies the song files (MIDI, `.progression`, pad reference) to `Velvet Chords` on the internal drive, backs up `MPC.settings`, adds the plugin to MPC's plugin list and starts MPC again. Running it again upgrades in place. Add `-y` to skip the prompt.

## First use

1. Make a new plugin track and choose **Velvet Chords** from the plugin browser (instrument plugins).
2. Hit pad A01. If you hear nothing, open the plugin's parameters, turn **Learn pad 1** on, and hit the pad you want as pad 1. Pads 2-64 follow from there (16 per bank, banks A-D).
3. Pick a **Mode**: Song, Smart scale, R&B kit, Chord types or Custom.

## The screen

The plugin comes with its own MPC screen skin, three pages on the function keys:

- **Play**: mode buttons, song and section pickers with the song's data status, 16 chord keys showing each pad's chord and function (the key you last played lights up; tap a key to hear it), the bank buttons A-D, a one-octave keyboard for the key with dots on the notes of the scale, the scale picker, voicing buttons, and a readout of the exact notes playing.
- **Perform**: sound, tone, release, volume, velocity curve, strum, arpeggiator, voicing, inversion, octave, transpose, voice leading, MIDI out, pad 1 note with Learn, and Export MIDI.
- **Edit**: tap a chord key to pick it, then set its root on the keyboard, its bass note, chord type, inversion and octave. Copy to Custom starts you from whatever layout you were playing.

The Q-Links follow the page. If the skin doesn't appear (for example `/sdcard/Synths` isn't in MPC's content locations; the installer warns about this), the plugin still works through MPC's generic parameter view.

## Parameters

| Parameter | What it does |
|---|---|
| Mode | Song, Smart scale, R&B kit, Chord types, Custom |
| Song | Song for Song mode |
| Section | Section on bank A; banks B-D get the following sections |
| Key, Scale | Key and scale for Smart scale, R&B kit and Chord types (17 scales) |
| Transpose | Shifts Song mode by -12 to +12 semitones; the song's original key stays in the data |
| Voicing | Bass + upper (default), Close, Drop 2, Spread, Upper only |
| Inversion, Octave | Global chord inversion and register |
| Voice lead | Pads in a bank are voiced to move smoothly from pad to pad |
| Strum, Strum dir | Delay between chord notes (0-150 ms), up/down/alternate |
| Arp, Arp rate | Arpeggiator (up, down, up-down, random), synced to the MPC tempo |
| Velocity | Linear, soft, hard or fixed response |
| Sound, Tone, Release, Volume | Built-in sound. *Silent* plays nothing (for MIDI out use) |
| Pad 1 note, Learn pad 1 | Which incoming note is pad A01 |
| MIDI out | Sends the chord notes to the host as MIDI. Whether MPC routes plugin MIDI output anywhere is untested |
| Edit pad / root / type / bass / inversion / octave | Edit a custom pad. Editing switches Mode to Custom |
| Edit follows pad | In Custom mode, hitting a pad selects it for editing |
| Copy to Custom | Copies the current layout into the custom pads so you can tweak it |
| Export MIDI | Saves the current section (or bank) as `.mid` and `.progression` in the `Velvet Chords` folder |
| Now playing | Last pad: chord, function and exact notes |
| Info | Song data status and confidence, or the scale's notes |

Custom pads, edits and settings are saved inside the MPC project.

## Uninstall

`ssh root@<device-ip> sh /tmp/VelvetChords-1.0.0/uninstall.sh` removes the plugin, its screen skin and its plugin-list entry (it also stops and restarts MPC). Your `Velvet Chords` folder with exports is kept. Projects that used the plugin load without it.

## Install by hand

1. Copy `payload/vst/velvetchords.so` to `/sdcard/vst/velvetchords.so`, `payload/Synths/Velvet Chords - VST - Velvet Chords/` to `/sdcard/Synths/`, and `payload/data/` to a `Velvet Chords` folder on the internal drive.
2. Stop MPC: `systemctl stop acvs`
3. Back up `MPC.settings` (`/media/az01-internal/Settings/*/MPC.settings`).
4. In `MPC.settings`, inside `<VALUE name="pluginList-arm"><KNOWNPLUGINS>`, add the line from `plugin.xml`. If there is no `pluginList-arm` value, add this just before `</PROPERTIES>`:
   ```xml
   <VALUE name="pluginList-arm">
     <KNOWNPLUGINS>
       (the line from plugin.xml)
     </KNOWNPLUGINS>
   </VALUE>
   ```
5. Start MPC: `systemctl start acvs`. If MPC shows default settings, restore your backup (the XML was malformed).

## Using the song files without the plugin

`payload/data/midi` holds a MIDI file per song section and per R&B kit, importable into any MPC sequence or DAW. `payload/data/progressions` holds Pad Perform `.progression` files. Their format follows commonly shared `.progression` files and has not been confirmed on a device, so compare one with a progression saved from your own MPC before relying on them.

## Song data

None of the songs is marked verified. Every entry is labeled `unverified-analysis` with a confidence level: the chord functions are well known, but extensions, bar placement and exact keys still need checking against the recordings. Pad voicings are generated performance voicings, not transcriptions of the records. To correct or add songs, edit `data/songs.json` in the source and rebuild.
